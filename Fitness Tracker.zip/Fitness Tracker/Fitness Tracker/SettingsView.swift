//
//  SettingsView.swift
//  Fitness Tracker
//
//  Created by Luisa Tanure on 10/7/24.
//

import SwiftUI

struct SettingsView: View {
    @ObservedObject var dailyData: DailyData
    @State private var dailies = Daily.exampleList
    @State private var someDaily = ""
    var body: some View {
        NavigationStack {
            List {
                Section("Enter"){
                // Adding new habits
                    TextField("new daily habit",text: $someDaily)
                        .onSubmit{
                            let newDaily = Daily(text: someDaily)
                            dailyData.addDaily(newDaily)
                            someDaily = ""
                        }
                }
            }
        }
    }
}

#Preview {
    SettingsView(dailyData: DailyData())
}
