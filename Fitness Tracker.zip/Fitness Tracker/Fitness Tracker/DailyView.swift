//
//  DailyView.swift
//  Fitness Tracker
//
//  Created by Luisa Tanure on 10/7/24.
//
import SwiftUI

// Habits Model
struct Daily: Identifiable {
    var id = UUID()
    var text: String
    var isDone: Bool = false

    static let exampleList: [Daily] = [
        Daily(text: "Drink water"),
        Daily(text: "Exercise"),
        Daily(text: "Read for 20 minutes")
    ]
}

// Class to manage habits list and its changes
class DailyData: ObservableObject {
    @Published var dailies: [Daily] = Daily.exampleList

    func addDaily(_ daily: Daily) {
        dailies.append(daily)
    }
}

struct DailyView: View {
// Declaring and initializing needed vars
    @ObservedObject var dailyData: DailyData
    @Binding var completedDailyCount: Int

    var body: some View {
        NavigationStack {
            List {
                    //Section for existing Habits
                        Section("Habits") {
                            ForEach($dailyData.dailies) { $daily in
                                DailyRowView(daily: $daily)
                                        .onChange(of: daily.isDone) {
                                            updateCompletedDailyCount()
                                        }
                            }
                            .onDelete { indexSet in
                                dailyData.dailies.remove(atOffsets: indexSet)
                            }
                        }
                    }
            .navigationTitle("Daily Habits")
            .toolbar {
            // SettingsView access for adding new habits
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink {
                        SettingsView(dailyData: dailyData)
                    } label: {
                        Image(systemName: "plus.app")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 30, height: 30)
                            .foregroundColor(.gray)
                            .padding()
                    }
                }
            }
        }
    }



// Rowview for a single habit
struct DailyRowView: View {
    @Binding var daily: Daily

    var body: some View {
        HStack {
            Button {
                daily.isDone.toggle()
            } label: {
                Image(systemName: daily.isDone ? "checkmark.square.fill" : "square")
            }
            Text(daily.text)
        }
    }
}
    
// func for updating daily habits count
    func updateCompletedDailyCount() {
        completedDailyCount = dailyData.dailies.filter { $0.isDone }.count
    }
}



#Preview {
    DailyView(dailyData: DailyData(), completedDailyCount: .constant(0))
}
