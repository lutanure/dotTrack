//
//  Fitness_TrackerApp.swift
//  Fitness Tracker
//
//  Created by Luisa Tanure on 10/7/24.
//

import SwiftUI

@main
struct Fitness_TrackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
