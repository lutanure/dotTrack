//
//  ContentView.swift
//  Fitness Tracker
//
//  Created by Luisa Tanure on 10/7/24.
//

import SwiftUI

struct ContentView: View {
// Declaring and initializing all vars for basic tracking
    let moodOpt = ["terrible", "meh", "okay", "good", "great"]
    @State private var SleepAmt = 5.0
    @State private var WaterAmt = 2.0
    @State private var PagesRead = 0.0
    @State private var stepsCount = 0.0
    @State private var workoutCount = 0.0
    @State private var prodCount = 0.0
    @State private var currentMood = "Okay"
    @State private var completedDailyCount = 0
    @State private var completedTodoCount = 0
    @StateObject var dailyData = DailyData()
    
// Initializing goals
    @AppStorage("sleepGoal") private var sleepGoal = 8.0
    @AppStorage("waterGoal") private var waterGoal = 8.0
    @AppStorage("pagesGoal") private var pagesGoal = 100.0
    @AppStorage("stepsGoal") private var stepsGoal = 10000.0
    @AppStorage("workoutGoal") private var workoutGoal = 2.0
    @AppStorage("prodGoal") private var prodGoal = 4.0
    
// Initializing bools for showing or not tracks
    @AppStorage("trackSleep") private var trackSleep = false
    @AppStorage("trackWater") private var trackWater = true
    @AppStorage("trackPages") private var trackPages = false
    @AppStorage("trackSteps") private var trackSteps = true
    @AppStorage("trackWorkouts") private var trackWorkouts = false
    @AppStorage("trackProductivity") private var trackProductivity = false
    @AppStorage("trackMood") private var trackMood = true
    

// Main Content View
    var body: some View {
        ZStack {
            NavigationStack {
            //Header
                ZStack {
                //Main Title
                    Text("dotTrack")
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                        .foregroundColor(.blue)
                        .shadow(radius: 0.2)
                        .padding()
                    
                //SideView (Sumamries)
                    HStack {
                        NavigationLink {
                            SideView(SleepAmt: SleepAmt, WaterAmt: WaterAmt, PagesRead: PagesRead,  stepsCount: stepsCount, workoutCount: workoutCount,  prodCount: prodCount, currentMood: currentMood, completedDailyCount: completedDailyCount, completedTodoCount: completedTodoCount)
                        } label: {
                            Image(systemName: "list.bullet.rectangle")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 40, height: 40)
                                .foregroundColor(.gray)
                        }
                        .buttonStyle(.plain)
                        .padding(.trailing, 16)
                        Spacer()
                    // SettingsView (Manage Tracks)
                        NavigationLink {
                            GoalsView()
                        } label: {
                            Image(systemName: "gear")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 40, height: 40)
                                .foregroundColor(.gray)
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.trailing)
                    .padding(.leading)
                }
                .frame(maxWidth: .infinity)
                .padding(.horizontal)
            
                        
                    List {
                    //DailyView (Daily Habits)
                        NavigationLink {
                            DailyView(dailyData: dailyData, completedDailyCount: $completedDailyCount)
                        } label: {
                            Text("Daily Habits")
                                .font(.custom("SF Pro", size: 20))
                        }
                        //TodoyView (Manage Todos)
                        NavigationLink {
                            TodoView(completedTodoCount: $completedTodoCount)
                        } label: {
                            Text("Todo's")
                                .font(.custom("SF Pro", size: 20))
                        }
                // Adding sections for each toggled track
                        if trackSleep {
                            Section("Hours of Sleep") {
                                Stepper("\(SleepAmt.formatted()) hours", value: $SleepAmt, in: 0...14)
                                    .font(.custom("SF Pro", size: 20))
                                ProgressRing(progress: SleepAmt, goal: sleepGoal, color: .yellow)
                            }
                        }

                        if trackWater {
                            Section("Cups of Water") {
                                Stepper("\(WaterAmt.formatted()) cups", value: $WaterAmt, in: 0...20)
                                    .font(.custom("SF Pro", size: 20))
                                ProgressRing(progress: WaterAmt, goal: waterGoal, color: .blue)
                                
                            }
                        }

                        if trackPages {
                            Section("Pages Read") {
                                Stepper("\(PagesRead.formatted()) pages", value: $PagesRead, in: 0...500, step: 10)
                                    .font(.custom("SF Pro", size: 20))
                                ProgressRing(progress: PagesRead, goal: pagesGoal, color: .purple)
                            }
                        }

                        if trackSteps {
                            Section("Steps") {
                                Stepper("\(stepsCount.formatted()) steps", value: $stepsCount, in: 0...50000, step: 1000)
                                    .font(.custom("SF Pro", size: 20))
                                ProgressRing(progress: stepsCount, goal: stepsGoal, color: .green)
                            }
                        }
                        if trackWorkouts {
                            Section("Workouts") {
                                Stepper("\(workoutCount.formatted()) workouts", value: $workoutCount, in: 0...5)
                                    .font(.custom("SF Pro", size: 20))
                                ProgressRing(progress: workoutCount, goal: workoutGoal, color: .red)
                            }
                        }
                        if trackProductivity {
                            Section("Productivity Hours") {
                                Stepper("\(prodCount.formatted()) productive hours", value: $prodCount, in: 0...18)
                                    .font(.custom("SF Pro", size: 20))
                                ProgressRing(progress: prodCount, goal: prodGoal, color: .gray)
                            }
                        }
                        if trackMood {
                            Section("Mood") {
                                Picker("Todays Overall Mood", selection: $currentMood){
                                ForEach(moodOpt,id:\.self){
                                    Text("\($0)")
                                }
                                }
                                .pickerStyle(.segmented)
                            }
                        }
                    }
                }
                .scrollContentBackground(.hidden)
                .background(Color.clear)
                .navigationTitle("dotTrack")
            }
        }
    }

//ProgressRing structure
struct ProgressRing: View {
    var progress: Double
    var goal: Double
    var color: Color
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(color.opacity(0.3), lineWidth: 5)
            Circle()
                .trim(from: 0.0, to: CGFloat(progress / goal))
                .stroke(color, lineWidth: 5)
                .rotationEffect(.degrees(-90))
                .animation(.easeInOut(duration: 0.5), value: progress)
            
            Text("\(Int(progress / goal * 100))%")
                .font(.headline)
                .bold()
        }
        .frame(width: 55, height: 55)
    }
}

    #Preview {
        ContentView()
    }



