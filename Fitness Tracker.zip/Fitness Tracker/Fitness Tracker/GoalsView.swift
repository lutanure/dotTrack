//
//  GoalsView.swift
//  Fitness Tracker
//
//  Created by Luisa Tanure on 10/7/24.
//

import SwiftUI

struct GoalsView: View {
// Fetch and set default values for track goals from persistent storage
        @AppStorage("sleepGoal") private var sleepGoal = 8.0
        @AppStorage("waterGoal") private var waterGoal = 8.0
        @AppStorage("pagesGoal") private var pagesGoal = 100.0
        @AppStorage("stepsGoal") private var stepsGoal = 10000.0
        @AppStorage("workoutsGoal") private var workoutsGoal = 5.0
        @AppStorage("productivityGoal") private var productivityGoal = 5.0

    // Toggle and fetch states for tracking features from persistent storage
        @AppStorage("trackSleep") private var trackSleep = false
        @AppStorage("trackWater") private var trackWater = false
        
        @AppStorage("trackPages") private var trackPages = false
        @AppStorage("trackSteps") private var trackSteps = false
        @AppStorage("trackWorkouts") private var trackWorkouts = false
        @AppStorage("trackProductivity") private var trackProductivity = false
        @AppStorage("trackMood") private var trackMood = false
    
    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Select Trackers")) {
                //Toggles for tracks
                    Toggle("Sleep", isOn: $trackSleep)
                    Toggle("Water Intake", isOn: $trackWater)
                    Toggle("Pages Read", isOn: $trackPages)
                    Toggle("Steps", isOn: $trackSteps)
                    Toggle("Workouts Completed", isOn: $trackWorkouts)
                    Toggle("Hours of Productivity", isOn: $trackProductivity)
                    Toggle("Mood", isOn: $trackMood)
                }
                
                Section(header: Text("Set Your Tracker Goals")) {
                            // Showing track settings depending on toggle status
                                    if trackSleep {
                                        HStack {
                                            Text("Hours of sleep: ")
                                            Spacer()
                                            Stepper("\(sleepGoal.formatted())", value: $sleepGoal, in: 2...14, step: 1)
                                        }
                                    }
                                    
                                    if trackWater {
                                        HStack {
                                            Text("Cups of water: ")
                                            Spacer()
                                            Stepper("\(waterGoal.formatted())", value: $waterGoal, in: 2...20, step: 1)
                                        }
                                    }

                                    if trackPages {
                                        HStack {
                                            Text("Pages of Book: ")
                                            Spacer()
                                            Stepper("\(pagesGoal.formatted())", value: $pagesGoal, in: 10...500, step: 10)
                                        }
                                    }
                                    
                                    if trackSteps {
                                        HStack {
                                            Text("Steps: ")
                                            Spacer()
                                            Stepper("\(stepsGoal.formatted())", value: $stepsGoal, in: 1000...50000, step: 1000)
                                        }
                                    }
                                    
                                    if trackWorkouts {
                                        HStack {
                                            Text("Workouts done: ")
                                            Spacer()
                                            Stepper("\(workoutsGoal.formatted())", value: $workoutsGoal, in: 1...5)
                                        }
                                    }

                                    if trackProductivity {
                                        HStack {
                                            Text("Productive Hours: ")
                                            Spacer()
                                            Stepper("\(productivityGoal.formatted())", value: $productivityGoal, in: 1...14)
                                        }
                                    }
                                }
                            }
                            .navigationTitle("Set Goals")        }
    }
}

#Preview {
    GoalsView()
}

