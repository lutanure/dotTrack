//
//  SideView.swift
//  Fitness Tracker
//
//  Created by Luisa Tanure on 10/8/24.
//

import SwiftUI

struct SideView: View {
// Setting example data for weekly view
    @State private var weeklySleep = [7.0, 6.5, 8.0, 7.0, 6.0, 7.5, 7.0] // Example data
    @State private var weeklyWater = [8.0, 7.0, 9.0, 6.0, 8.5, 7.5, 7.0] // Example data
    @State private var weeklyPages = [100.0, 50.0, 70.0, 90.0, 80.0, 60.0, 50.0]  // Example data
    @State private var weeklySteps = [1000.0, 10000.0, 6000.0,7000.0, 2000.0, 11000.0, 8000.0,] // Example data
    @State private var weeklyWorkouts = [1.0, 2.0, 2.0, 2.0, 2.0, 0.0, 1.0, ] // Example data
    @State private var weeklyProd = [2.0, 2.0, 3.0, 2.0, 4.0, 0.0,1.0] // Example data
    @State private var weeklyMood = ["good", "meh", "okay", "good", "great"] // Example data
    @State private var weeklyTodos = [4, 5, 6, 1, 5, 7, 10] // Example data
    @State private var weeklyHabits = [5, 5, 5, 2, 5, 1, 2] // Example data
    
// Declaring variables for the current status of trackers
    var SleepAmt: Double
    var WaterAmt: Double
    var PagesRead: Double
    var stepsCount: Double
    var workoutCount: Double
    var prodCount: Double
    var currentMood:String
    var completedDailyCount: Int
    var completedTodoCount: Int
    

// Storing and fetching the toggle status of tracks
    @AppStorage("trackWater") private var trackWater = false
    @AppStorage("trackSleep") private var trackSleep = false
    @AppStorage("trackPages") private var trackPages = false
    @AppStorage("trackSteps") private var trackSteps = false
    @AppStorage("trackWorkouts") private var trackWorkouts = false
    @AppStorage("trackProductivity") private var trackProductivity = false
    @AppStorage("trackMood") private var trackMood = false
    
    var body: some View {
        ZStack{
            Color((.systemGray6))
                .ignoresSafeArea()
            NavigationStack {
                // Title
                    Text("Overview")
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .padding()
                List{
                // Daily Summary
                    Section(){
                        Text("Daily Summary")
                            .font(.custom("SF Pro", size: 22))
                            .padding()
                        
                    // Daily Summary outputs
                        VStack {
                            DailyFormat(measureName: "Sleep", someTrack: trackSleep, someCount: SleepAmt, sufix: "hours")
                            DailyFormat(measureName: "Water", someTrack: trackWater, someCount: WaterAmt, sufix: "cups")
                            DailyFormat(measureName: "Pages", someTrack: trackPages, someCount: PagesRead, sufix: "pages")
                            DailyFormat(measureName: "Steps", someTrack: trackSteps, someCount: stepsCount, sufix: "")
                            DailyFormat(measureName: "Workouts", someTrack: trackWorkouts, someCount: workoutCount, sufix: "completed")
                            DailyFormat(measureName: "Productivity", someTrack: trackProductivity, someCount: prodCount, sufix: "hours")
                            
                            if trackMood{
                                Text("Mood: \(currentMood)")
                                    .font(.custom("SF Pro", size: 20))
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            Text("Todo's: \(completedTodoCount) done")
                                .font(.custom("SF Pro", size: 20))
                                .frame(maxWidth: .infinity, alignment: .leading)
                            Text("Daily habits: \(completedDailyCount) kept")
                                .font(.custom("SF Pro", size: 20))
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .padding()
                        
                    }
                // Weekly Reports
                    Section{
                        
                        Text("Weekly Report")
                            .font(.custom("SF Pro", size: 22))
                            .padding()
                        
                        VStack {
                            if trackSleep{
                                Text("Average Sleep: \(average(weeklySleep).formatted()) hours")
                                    .font(.custom("SF Pro", size: 20))
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            if trackWater{
                                Text("Average Water: \(average(weeklyWater).formatted(.number.precision(.significantDigits(2)))) cups")
                                    .font(.custom("SF Pro", size: 20))
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            if trackPages{
                                Text("Total Pages Read: \(total(weeklyPages).formatted()) pages")
                                    .font(.custom("SF Pro", size: 20))
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            if trackSteps{
                                Text("Average Steps: \(average(weeklySteps).formatted(.number.precision(.significantDigits(4))))")
                                    .font(.custom("SF Pro", size: 20))
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            if trackWorkouts{
                                Text("Average Workouts: \(average(weeklyWorkouts).formatted(.number.precision(.significantDigits(2))))")
                                    .font(.custom("SF Pro", size: 20))
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            if trackProductivity{
                                Text("Average Productivity:  \(average(weeklyProd).formatted()) hours")
                                    .font(.custom("SF Pro", size: 20))
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            if trackMood{
                                Text("Overall Mood: \(mostFrequentMood(in: weeklyMood))")
                                    .font(.custom("SF Pro", size: 20))
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            Text("Total Todo's: \(totalInt(weeklyTodos)) done")
                                .font(.custom("SF Pro", size: 20))
                                .frame(maxWidth: .infinity, alignment: .leading)
                            Text("Total Daily habits: \(totalInt(weeklyHabits)) kept")
                                .font(.custom("SF Pro", size: 20))
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .padding()
                    }
                }
            }
        }
    }

// func to average data of a list of DOUBLES
    func average(_ data: [Double]) -> Double {
        return data.reduce(0, +) / Double(data.count)
    }
// func to get sum of list of DOUBLES
    func total(_ data: [Double]) -> Double {
        return data.reduce(0, +)
    }
// func to average data of a list of INTs
    func totalInt(_ data: [Int]) -> Int {
        return data.reduce(0, +)
}
// func to find the most frequent mood in a list
    func mostFrequentMood(in moods: [String]) -> String {
        guard !moods.isEmpty else { return "No overall mood" }

        let moodCount = moods.reduce(into: [String: Int]()) { counts, mood in
            counts[mood, default: 0] += 1
        }
        
        if let mostFrequent = moodCount.max(by: { $0.value < $1.value })?.key {
            return mostFrequent
        } else {
            return "No overall mood"
        }
    }

}
    

// Struct for daily averages
struct DailyFormat: View{
    let measureName : String
    let someTrack : Bool
    let someCount : Double
    let sufix : String
    var body: some View{
        if someTrack{
                Text("\(measureName): \(someCount.formatted()) \(sufix)")
                    .font(.custom("SF Pro", size: 20))
                    .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}


#Preview {
    SideView(SleepAmt: 7, WaterAmt: 8, PagesRead: 50, stepsCount: 1000,  workoutCount: 2, prodCount: 2, currentMood: "Okay", completedDailyCount: 2, completedTodoCount: 1)
}
