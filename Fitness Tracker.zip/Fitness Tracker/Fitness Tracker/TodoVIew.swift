//
//  TodoVIew.swift
//  Fitness Tracker
//
//  Created by Luisa Tanure on 10/7/24.
//

import SwiftUI

// Todo Model
struct Todo: Identifiable {
    var id = UUID()
    var text: String
    var isDone: Bool = false
}

//  Managing todos
class TodoData: ObservableObject {
    @Published var todos: [Todo] = loadTodos()
    
    func addTodo(_ todo: Todo) {
        todos.append(todo)
        saveTodos(todos)
    }
}

struct TodoView: View {
// Declaring and initializing needed vars
    @ObservedObject var todoData = TodoData()
    @State private var someTodo = ""
    @Binding var completedTodoCount: Int
    
    var body: some View {
        NavigationStack {
            List {
            // Section for adding todos
                Section("Enter") {
                    TextField("new todo", text: $someTodo)
                        .onSubmit {
                            let newTodo = Todo(text: someTodo)
                            todoData.addTodo(newTodo)
                            someTodo = ""
                            updateCompletedTodoCount()
                        }
                }
            // Section for existing todos
                Section("ToDos") {
                    ForEach($todoData.todos) { $todo in
                        TodoRowView(todo: $todo)
                            .onChange(of: todo.isDone) {
                                updateCompletedTodoCount()
                            }
                    }
                    .onDelete { indexSet in
                        todoData.todos.remove(atOffsets: indexSet)
                        saveTodos(todoData.todos)
                    }
                }
            }
            .navigationTitle("Todo List")
        }
    }
    
// Update todo count
    func updateCompletedTodoCount() {
        completedTodoCount = todoData.todos.filter { $0.isDone }.count
    }
}

// Row view for todo item
struct TodoRowView: View {
    @Binding var todo: Todo
    
    var body: some View {
        HStack {
            Button {
                todo.isDone.toggle()
            } label: {
                Image(systemName: todo.isDone ? "checkmark.square.fill" : "square")
                .transition(.scale)
            }
            Text(todo.text)
        }
    }
}

// func to save todos
func saveTodos(_ todos: [Todo]) {
    let todoTexts = todos.map { $0.text }
    let todoStatuses = todos.map { $0.isDone }
    
    UserDefaults.standard.set(todoTexts, forKey: "todoTexts")
    UserDefaults.standard.set(todoStatuses, forKey: "todoStatuses")
}

// func to load todos
func loadTodos() -> [Todo] {
    let todoTexts = UserDefaults.standard.stringArray(forKey: "todoTexts") ?? []
    let todoStatuses = UserDefaults.standard.array(forKey: "todoStatuses") as? [Bool] ?? []
    
    var todos: [Todo] = []
    for (index, text) in todoTexts.enumerated() {
        let isDone = index < todoStatuses.count ? todoStatuses[index] : false
        todos.append(Todo(text: text, isDone: isDone))
    }
    return todos
}


#Preview {
    TodoView(completedTodoCount: .constant(0))
}
